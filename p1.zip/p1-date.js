/*
CIT 281 Project 1
Name: Finn O'Donnell
*/

const days = ['sunday','monday','tuesday','wednesday','thursday','friday','saturday'];
const date = new Date();

console.log(days[date.getDay()]);