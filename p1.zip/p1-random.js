/*
CIT 281 Project 1
Name: Finn O'Donnell
*/

const alphabet = 
['a','b','c','d','e','f','g','h','i',
'j','k','l','m','n','o','p','q','r',
's','t','u','v','w','x','y','z'];



let str = ""
for(i = getRandomInteger(5,26); i != 0; i-- ){

    str = str + alphabet[getRandomInteger(0,27)];
}

console.log(str);


// Returns a random number between min (inclusive) and max (exclusive)



function getRandomInteger(min, max) {
    return Math.floor(Math.random() * (max - min) + min);
}

